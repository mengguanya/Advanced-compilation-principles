#include <stdio.h>
#define WriteLine() printf("\n");
#define WriteLong(x) printf(" %lld", (long)x);
#define ReadLong(a) if (fscanf(stdin, "%lld", &a) != 1) a = 0;
#define long long long
long res;
void Func_2 (long n ){
if((n==0)){
res=1;
}
else{
Func_2((n-1));
res=(n*res);
}
}
void Func_17 (long n ){
long x;
long y;
if((n<=1)){
res=1;
}
else{
Func_17((n-1));
x=res;
Func_17((n-2));
y=res;
res=(x+y);
}
}
long count;
void Func_39 (long from,long to ){
WriteLong(from);
WriteLong(to);
WriteLine();
count=(count+1);
}
void Func_49 (long from,long by,long to,long height ){
if((height==1)){
Func_39(from,to);
}
else{
Func_49(from,to,by,(height-1));
Func_39(from,to);
Func_49(by,from,to,(height-1));
}
}
void Func_72 (long height ){
count=0;
Func_49(1,2,3,height);
WriteLine();
WriteLong(count);
WriteLine();
}
long a;
long m;
long q;
long r;
void main ( ){
a=16807;
m=127;
m=((m*256)+255);
m=((m*256)+255);
m=((m*256)+255);
q=(m/a);
r=(m%a);
Func_2(7);
WriteLong(res);
WriteLine();
WriteLine();
Func_17(11);
WriteLong(res);
WriteLine();
WriteLine();
Func_72(3);
WriteLine();
}
